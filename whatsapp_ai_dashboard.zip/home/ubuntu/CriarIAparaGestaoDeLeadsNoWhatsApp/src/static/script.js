// Estado da aplicação
let leads = [];
let filteredLeads = [];

// Elementos DOM
const elements = {
    totalLeads: document.getElementById('totalLeads'),
    notResponded: document.getElementById('notResponded'),
    closed: document.getElementById('closed'),
    objections: document.getElementById('objections'),
    leadsTableBody: document.getElementById('leadsTableBody'),
    statusFilter: document.getElementById('statusFilter'),
    sellerFilter: document.getElementById('sellerFilter'),
    searchFilter: document.getElementById('searchFilter'),
    clearFilters: document.getElementById('clearFilters'),
    refreshBtn: document.getElementById('refreshBtn'),
    exportBtn: document.getElementById('exportBtn'),
    editModal: document.getElementById('editModal'),
    editForm: document.getElementById('editForm'),
    notifications: document.getElementById('notifications')
};

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    loadLeads();
    setupEventListeners();
});

// Event Listeners
function setupEventListeners() {
    elements.refreshBtn.addEventListener('click', loadLeads);
    elements.exportBtn.addEventListener('click', exportToExcel);
    elements.statusFilter.addEventListener('change', applyFilters);
    elements.sellerFilter.addEventListener('change', applyFilters);
    elements.searchFilter.addEventListener('input', applyFilters);
    elements.clearFilters.addEventListener('click', clearFilters);
    
    // Modal events
    document.getElementById('cancelEdit').addEventListener('click', closeEditModal);
    document.getElementById('saveEdit').addEventListener('click', saveLeadEdit);
    
    // Fechar modal ao clicar fora
    elements.editModal.addEventListener('click', function(e) {
        if (e.target === elements.editModal) {
            closeEditModal();
        }
    });
}

// Carregar leads do servidor
async function loadLeads() {
    try {
        showLoading();
        
        const [leadsResponse, statsResponse] = await Promise.all([
            fetch('/api/leads'),
            fetch('/api/leads/stats')
        ]);
        
        if (!leadsResponse.ok || !statsResponse.ok) {
            throw new Error('Erro ao carregar dados');
        }
        
        leads = await leadsResponse.json();
        const stats = await statsResponse.json();
        
        updateStats(stats);
        updateSellersFilter();
        applyFilters();
        
        hideLoading();
        showNotification('Dados atualizados com sucesso', 'success');
        
    } catch (error) {
        console.error('Erro ao carregar leads:', error);
        showNotification('Erro ao carregar dados', 'error');
        hideLoading();
    }
}

// Atualizar estatísticas
function updateStats(stats) {
    elements.totalLeads.textContent = stats.total_leads || 0;
    elements.notResponded.textContent = stats.not_responded || 0;
    elements.closed.textContent = stats.closed || 0;
    elements.objections.textContent = stats.objections || 0;
}

// Atualizar filtro de vendedores
function updateSellersFilter() {
    const sellers = [...new Set(leads.map(lead => lead.assigned_seller).filter(Boolean))];
    
    elements.sellerFilter.innerHTML = '<option value="">Todos</option>';
    sellers.forEach(seller => {
        const option = document.createElement('option');
        option.value = seller;
        option.textContent = seller;
        elements.sellerFilter.appendChild(option);
    });
}

// Aplicar filtros
function applyFilters() {
    const statusFilter = elements.statusFilter.value;
    const sellerFilter = elements.sellerFilter.value;
    const searchFilter = elements.searchFilter.value.toLowerCase();
    
    filteredLeads = leads.filter(lead => {
        const matchesStatus = !statusFilter || lead.status === statusFilter;
        const matchesSeller = !sellerFilter || lead.assigned_seller === sellerFilter;
        const matchesSearch = !searchFilter || 
            (lead.name && lead.name.toLowerCase().includes(searchFilter)) ||
            lead.phone_number.includes(searchFilter);
        
        return matchesStatus && matchesSeller && matchesSearch;
    });
    
    renderLeadsTable();
}

// Renderizar tabela de leads
function renderLeadsTable() {
    if (filteredLeads.length === 0) {
        elements.leadsTableBody.innerHTML = `
            <tr>
                <td colspan="6" class="px-6 py-8 text-center text-gray-500">
                    <i class="fas fa-inbox text-4xl mb-2"></i>
                    <p>Nenhum lead encontrado</p>
                </td>
            </tr>
        `;
        return;
    }
    
    elements.leadsTableBody.innerHTML = filteredLeads.map(lead => `
        <tr class="hover:bg-gray-50 transition-colors">
            <td class="px-6 py-4 whitespace-nowrap">
                <div>
                    <div class="text-sm font-medium text-gray-900">
                        ${lead.name || 'Nome não informado'}
                    </div>
                    <div class="text-sm text-gray-500">
                        <i class="fab fa-whatsapp mr-1"></i>${lead.phone_number}
                    </div>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="status-badge ${getStatusClass(lead.status)}">
                    ${lead.status}
                </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                ${lead.objection_type ? `
                    <div class="text-sm text-gray-900">${lead.objection_type}</div>
                    ${lead.objection_details ? `<div class="text-xs text-gray-500">${lead.objection_details}</div>` : ''}
                ` : '<span class="text-gray-400">-</span>'}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                ${lead.assigned_seller || '<span class="text-gray-400">Não atribuído</span>'}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                ${formatDate(lead.updated_at)}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button onclick="editLead(${lead.id})" class="text-blue-600 hover:text-blue-900 mr-3">
                    <i class="fas fa-edit"></i> Editar
                </button>
                <button onclick="viewMessages(${lead.id})" class="text-green-600 hover:text-green-900">
                    <i class="fas fa-comments"></i> Mensagens
                </button>
            </td>
        </tr>
    `).join('');
}

// Obter classe CSS para status
function getStatusClass(status) {
    const statusMap = {
        'Não Respondido': 'status-nao-respondido',
        'Respondido': 'status-respondido',
        'Orçamento Enviado': 'status-orcamento-enviado',
        'Objeção': 'status-objecao',
        'Fechado': 'status-fechado',
        'Perdido': 'status-perdido'
    };
    return statusMap[status] || 'status-nao-respondido';
}

// Formatar data
function formatDate(dateString) {
    if (!dateString) return '-';
    
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Hoje';
    if (diffDays === 2) return 'Ontem';
    if (diffDays <= 7) return `${diffDays} dias atrás`;
    
    return date.toLocaleDateString('pt-BR');
}

// Editar lead
function editLead(leadId) {
    const lead = leads.find(l => l.id === leadId);
    if (!lead) return;
    
    // Preencher formulário
    document.getElementById('editLeadId').value = lead.id;
    document.getElementById('editName').value = lead.name || '';
    document.getElementById('editStatus').value = lead.status;
    document.getElementById('editObjectionType').value = lead.objection_type || '';
    document.getElementById('editObjectionDetails').value = lead.objection_details || '';
    document.getElementById('editSeller').value = lead.assigned_seller || '';
    document.getElementById('editSatisfied').checked = lead.is_satisfied === true;
    document.getElementById('editPendingQuestions').checked = lead.has_pending_questions === true;
    
    // Mostrar modal
    elements.editModal.classList.remove('hidden');
    elements.editModal.classList.add('flex');
}

// Fechar modal de edição
function closeEditModal() {
    elements.editModal.classList.add('hidden');
    elements.editModal.classList.remove('flex');
}

// Salvar edição do lead
async function saveLeadEdit() {
    try {
        const leadId = document.getElementById('editLeadId').value;
        const formData = {
            name: document.getElementById('editName').value,
            status: document.getElementById('editStatus').value,
            objection_type: document.getElementById('editObjectionType').value,
            objection_details: document.getElementById('editObjectionDetails').value,
            assigned_seller: document.getElementById('editSeller').value,
            is_satisfied: document.getElementById('editSatisfied').checked,
            has_pending_questions: document.getElementById('editPendingQuestions').checked
        };
        
        const response = await fetch(`/api/leads/${leadId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        if (!response.ok) {
            throw new Error('Erro ao salvar alterações');
        }
        
        closeEditModal();
        loadLeads();
        showNotification('Lead atualizado com sucesso', 'success');
        
    } catch (error) {
        console.error('Erro ao salvar lead:', error);
        showNotification('Erro ao salvar alterações', 'error');
    }
}

// Ver mensagens do lead
function viewMessages(leadId) {
    // Implementar visualização de mensagens
    showNotification('Funcionalidade em desenvolvimento', 'info');
}

// Limpar filtros
function clearFilters() {
    elements.statusFilter.value = '';
    elements.sellerFilter.value = '';
    elements.searchFilter.value = '';
    applyFilters();
}

// Exportar para Excel
async function exportToExcel() {
    try {
        showLoading();
        
        const response = await fetch('/api/export/excel', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error('Erro ao gerar planilha');
        }
        
        const result = await response.json();
        
        // Fazer download do arquivo
        window.open(`/api/export/download/${result.filename}`, '_blank');
        
        hideLoading();
        showNotification('Planilha gerada com sucesso', 'success');
        
    } catch (error) {
        console.error('Erro ao exportar:', error);
        showNotification('Erro ao gerar planilha', 'error');
        hideLoading();
    }
}

// Mostrar loading
function showLoading() {
    elements.refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Carregando...';
    elements.refreshBtn.disabled = true;
}

// Esconder loading
function hideLoading() {
    elements.refreshBtn.innerHTML = '<i class="fas fa-sync-alt mr-2"></i>Atualizar';
    elements.refreshBtn.disabled = false;
}

// Mostrar notificação
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification px-4 py-3 rounded-lg shadow-lg text-white ${getNotificationClass(type)}`;
    
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${getNotificationIcon(type)} mr-2"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white hover:text-gray-200">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    elements.notifications.appendChild(notification);
    
    // Remover automaticamente após 5 segundos
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Obter classe CSS para notificação
function getNotificationClass(type) {
    const typeMap = {
        'success': 'bg-green-500',
        'error': 'bg-red-500',
        'warning': 'bg-yellow-500',
        'info': 'bg-blue-500'
    };
    return typeMap[type] || 'bg-blue-500';
}

// Obter ícone para notificação
function getNotificationIcon(type) {
    const iconMap = {
        'success': 'fa-check-circle',
        'error': 'fa-exclamation-circle',
        'warning': 'fa-exclamation-triangle',
        'info': 'fa-info-circle'
    };
    return iconMap[type] || 'fa-info-circle';
}

