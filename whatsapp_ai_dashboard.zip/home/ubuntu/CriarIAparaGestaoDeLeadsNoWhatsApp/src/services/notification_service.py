import smtplib
import json
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from src.models.lead import Lead, Message, db
import requests
import os

class NotificationService:
    
    def __init__(self):
        # Configurações de email (podem ser definidas via variáveis de ambiente)
        self.smtp_server = os.getenv('SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = int(os.getenv('SMTP_PORT', '587'))
        self.email_user = os.getenv('EMAIL_USER', '')
        self.email_password = os.getenv('EMAIL_PASSWORD', '')
        
        # Configurações de webhook/Slack (opcional)
        self.slack_webhook_url = os.getenv('SLACK_WEBHOOK_URL', '')
        
        # Lista de vendedores e seus emails
        self.sellers_config = {
            'vendedor1@empresa.com': ['Vendedor 1'],
            'vendedor2@empresa.com': ['Vendedor 2'],
            'gerente@empresa.com': ['*']  # Recebe todas as notificações
        }
    
    def send_new_lead_notification(self, lead):
        """Envia notificação quando um novo lead chega"""
        try:
            subject = f"🔔 Novo Lead Recebido - {lead.phone_number}"
            
            message = f"""
            <h2>Novo Lead Recebido!</h2>
            <p><strong>Telefone:</strong> {lead.phone_number}</p>
            <p><strong>Nome:</strong> {lead.name or 'Não informado'}</p>
            <p><strong>Última Mensagem:</strong> {lead.last_message or 'Nenhuma mensagem'}</p>
            <p><strong>Data:</strong> {lead.created_at.strftime('%d/%m/%Y %H:%M')}</p>
            
            <p>Acesse o dashboard para responder: <a href="http://localhost:5000">Dashboard</a></p>
            """
            
            self._send_email_notification(subject, message)
            self._send_slack_notification(f"🔔 Novo lead: {lead.phone_number}")
            
            return True
            
        except Exception as e:
            print(f"Erro ao enviar notificação de novo lead: {e}")
            return False
    
    def send_status_change_notification(self, lead, old_status, new_status):
        """Envia notificação quando o status de um lead muda"""
        try:
            subject = f"📊 Status Alterado - {lead.phone_number}"
            
            message = f"""
            <h2>Status do Lead Alterado</h2>
            <p><strong>Cliente:</strong> {lead.name or lead.phone_number}</p>
            <p><strong>Status Anterior:</strong> {old_status}</p>
            <p><strong>Novo Status:</strong> {new_status}</p>
            <p><strong>Data da Alteração:</strong> {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
            
            {self._get_status_action_suggestion(new_status)}
            
            <p>Acesse o dashboard: <a href="http://localhost:5000">Dashboard</a></p>
            """
            
            # Enviar apenas para vendedores relevantes
            if lead.assigned_seller:
                self._send_targeted_email(subject, message, lead.assigned_seller)
            else:
                self._send_email_notification(subject, message)
            
            self._send_slack_notification(f"📊 {lead.phone_number}: {old_status} → {new_status}")
            
            return True
            
        except Exception as e:
            print(f"Erro ao enviar notificação de mudança de status: {e}")
            return False
    
    def send_objection_notification(self, lead):
        """Envia notificação quando um lead tem objeção"""
        try:
            subject = f"⚠️ Objeção Identificada - {lead.phone_number}"
            
            message = f"""
            <h2>Objeção Identificada!</h2>
            <p><strong>Cliente:</strong> {lead.name or lead.phone_number}</p>
            <p><strong>Tipo de Objeção:</strong> {lead.objection_type}</p>
            <p><strong>Detalhes:</strong> {lead.objection_details or 'Não especificado'}</p>
            <p><strong>Última Mensagem:</strong> {lead.last_message}</p>
            
            <h3>Sugestões de Ação:</h3>
            {self._get_objection_suggestions(lead.objection_type)}
            
            <p>Acesse o dashboard: <a href="http://localhost:5000">Dashboard</a></p>
            """
            
            # Prioridade alta para objeções
            if lead.assigned_seller:
                self._send_targeted_email(subject, message, lead.assigned_seller, priority='high')
            else:
                self._send_email_notification(subject, message, priority='high')
            
            self._send_slack_notification(f"⚠️ Objeção: {lead.phone_number} - {lead.objection_type}")
            
            return True
            
        except Exception as e:
            print(f"Erro ao enviar notificação de objeção: {e}")
            return False
    
    def send_satisfaction_alert(self, lead, is_satisfied):
        """Envia alerta sobre satisfação do cliente"""
        try:
            if is_satisfied:
                subject = f"😊 Cliente Satisfeito - {lead.phone_number}"
                emoji = "😊"
                status_text = "satisfeito"
            else:
                subject = f"😟 Cliente Insatisfeito - {lead.phone_number}"
                emoji = "😟"
                status_text = "insatisfeito"
            
            message = f"""
            <h2>Alerta de Satisfação do Cliente</h2>
            <p><strong>Cliente:</strong> {lead.name or lead.phone_number}</p>
            <p><strong>Status:</strong> Cliente {status_text}</p>
            <p><strong>Vendedor:</strong> {lead.assigned_seller or 'Não atribuído'}</p>
            <p><strong>Data:</strong> {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
            
            {'<p style="color: green;">Continue o bom trabalho!</p>' if is_satisfied else '<p style="color: red;">Ação imediata necessária para recuperar o cliente.</p>'}
            
            <p>Acesse o dashboard: <a href="http://localhost:5000">Dashboard</a></p>
            """
            
            if lead.assigned_seller:
                self._send_targeted_email(subject, message, lead.assigned_seller)
            
            self._send_slack_notification(f"{emoji} {lead.phone_number}: Cliente {status_text}")
            
            return True
            
        except Exception as e:
            print(f"Erro ao enviar alerta de satisfação: {e}")
            return False
    
    def send_pending_questions_alert(self, lead):
        """Envia alerta sobre dúvidas pendentes"""
        try:
            subject = f"❓ Dúvidas Pendentes - {lead.phone_number}"
            
            message = f"""
            <h2>Cliente com Dúvidas Pendentes</h2>
            <p><strong>Cliente:</strong> {lead.name or lead.phone_number}</p>
            <p><strong>Vendedor:</strong> {lead.assigned_seller or 'Não atribuído'}</p>
            <p><strong>Última Mensagem:</strong> {lead.last_message}</p>
            <p><strong>Data:</strong> {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
            
            <p style="color: orange;"><strong>Ação Necessária:</strong> Cliente aguarda esclarecimentos. Responda o mais rápido possível.</p>
            
            <p>Acesse o dashboard: <a href="http://localhost:5000">Dashboard</a></p>
            """
            
            if lead.assigned_seller:
                self._send_targeted_email(subject, message, lead.assigned_seller, priority='high')
            else:
                self._send_email_notification(subject, message, priority='high')
            
            self._send_slack_notification(f"❓ {lead.phone_number}: Dúvidas pendentes")
            
            return True
            
        except Exception as e:
            print(f"Erro ao enviar alerta de dúvidas pendentes: {e}")
            return False
    
    def send_daily_summary(self):
        """Envia resumo diário dos leads"""
        try:
            today = datetime.now().date()
            yesterday = today - timedelta(days=1)
            
            # Estatísticas do dia
            new_leads_today = Lead.query.filter(
                Lead.created_at >= today
            ).count()
            
            closed_today = Lead.query.filter(
                Lead.updated_at >= today,
                Lead.status == 'Fechado'
            ).count()
            
            pending_leads = Lead.query.filter(
                Lead.status == 'Não Respondido'
            ).count()
            
            objections_today = Lead.query.filter(
                Lead.updated_at >= today,
                Lead.status == 'Objeção'
            ).count()
            
            subject = f"📊 Resumo Diário - {today.strftime('%d/%m/%Y')}"
            
            message = f"""
            <h2>Resumo Diário de Leads</h2>
            <p><strong>Data:</strong> {today.strftime('%d/%m/%Y')}</p>
            
            <h3>Estatísticas do Dia:</h3>
            <ul>
                <li><strong>Novos Leads:</strong> {new_leads_today}</li>
                <li><strong>Vendas Fechadas:</strong> {closed_today}</li>
                <li><strong>Leads Pendentes:</strong> {pending_leads}</li>
                <li><strong>Objeções:</strong> {objections_today}</li>
            </ul>
            
            <p>Acesse o dashboard para mais detalhes: <a href="http://localhost:5000">Dashboard</a></p>
            """
            
            self._send_email_notification(subject, message)
            
            return True
            
        except Exception as e:
            print(f"Erro ao enviar resumo diário: {e}")
            return False
    
    def _send_email_notification(self, subject, message, priority='normal'):
        """Envia notificação por email"""
        if not self.email_user or not self.email_password:
            print("Configurações de email não definidas")
            return False
        
        try:
            msg = MIMEMultipart()
            msg['From'] = self.email_user
            msg['Subject'] = subject
            
            if priority == 'high':
                msg['X-Priority'] = '1'
                msg['X-MSMail-Priority'] = 'High'
            
            msg.attach(MIMEText(message, 'html'))
            
            # Enviar para todos os emails configurados
            recipients = list(self.sellers_config.keys())
            msg['To'] = ', '.join(recipients)
            
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            server.login(self.email_user, self.email_password)
            server.send_message(msg)
            server.quit()
            
            return True
            
        except Exception as e:
            print(f"Erro ao enviar email: {e}")
            return False
    
    def _send_targeted_email(self, subject, message, seller_name, priority='normal'):
        """Envia email para vendedor específico"""
        target_emails = []
        
        for email, sellers in self.sellers_config.items():
            if '*' in sellers or seller_name in sellers:
                target_emails.append(email)
        
        if not target_emails:
            return self._send_email_notification(subject, message, priority)
        
        # Implementar envio direcionado (similar ao método anterior)
        return True
    
    def _send_slack_notification(self, message):
        """Envia notificação para Slack"""
        if not self.slack_webhook_url:
            return False
        
        try:
            payload = {
                'text': message,
                'username': 'WhatsApp AI Bot',
                'icon_emoji': ':robot_face:'
            }
            
            response = requests.post(self.slack_webhook_url, json=payload)
            return response.status_code == 200
            
        except Exception as e:
            print(f"Erro ao enviar para Slack: {e}")
            return False
    
    def _get_status_action_suggestion(self, status):
        """Retorna sugestões de ação baseadas no status"""
        suggestions = {
            'Não Respondido': '<p style="color: red;"><strong>Ação:</strong> Responder o cliente o mais rápido possível.</p>',
            'Respondido': '<p style="color: blue;"><strong>Ação:</strong> Preparar orçamento se necessário.</p>',
            'Orçamento Enviado': '<p style="color: orange;"><strong>Ação:</strong> Acompanhar resposta do cliente.</p>',
            'Objeção': '<p style="color: red;"><strong>Ação:</strong> Trabalhar a objeção identificada.</p>',
            'Fechado': '<p style="color: green;"><strong>Parabéns!</strong> Venda realizada com sucesso.</p>',
            'Perdido': '<p style="color: gray;"><strong>Ação:</strong> Analisar motivos da perda para melhorias futuras.</p>'
        }
        
        return suggestions.get(status, '')
    
    def _get_objection_suggestions(self, objection_type):
        """Retorna sugestões para lidar com objeções"""
        suggestions = {
            'Preço': '''
                <ul>
                    <li>Demonstre o valor do produto/serviço</li>
                    <li>Compare com concorrentes</li>
                    <li>Ofereça condições de pagamento</li>
                    <li>Mostre o ROI/benefícios</li>
                </ul>
            ''',
            'Prazo de Entrega': '''
                <ul>
                    <li>Explique o processo de produção/entrega</li>
                    <li>Ofereça alternativas de prazo</li>
                    <li>Demonstre qualidade vs. velocidade</li>
                    <li>Considere priorização mediante taxa</li>
                </ul>
            ''',
            'Produto Caro': '''
                <ul>
                    <li>Foque no custo-benefício</li>
                    <li>Apresente opções mais econômicas</li>
                    <li>Divida o investimento no tempo</li>
                    <li>Compare com custos de não ter o produto</li>
                </ul>
            ''',
            'Outro': '''
                <ul>
                    <li>Identifique a objeção específica</li>
                    <li>Faça perguntas para entender melhor</li>
                    <li>Ofereça soluções personalizadas</li>
                    <li>Agende uma conversa mais detalhada</li>
                </ul>
            '''
        }
        
        return suggestions.get(objection_type, '<p>Analise a objeção específica e responda adequadamente.</p>')

