import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils.dataframe import dataframe_to_rows
from datetime import datetime
import os
from src.models.lead import Lead, Message

class SpreadsheetService:
    
    def __init__(self):
        self.output_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'exports')
        os.makedirs(self.output_dir, exist_ok=True)
    
    def generate_leads_excel(self, filename=None):
        """Gera planilha Excel com todos os leads"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"leads_report_{timestamp}.xlsx"
        
        filepath = os.path.join(self.output_dir, filename)
        
        # Buscar todos os leads
        leads = Lead.query.all()
        
        # Converter para DataFrame
        leads_data = []
        for lead in leads:
            leads_data.append({
                'ID': lead.id,
                'Telefone': lead.phone_number,
                'Nome': lead.name or 'Não informado',
                'Status': lead.status,
                'Tipo de Objeção': lead.objection_type or '',
                'Detalhes da Objeção': lead.objection_details or '',
                'Última Mensagem': lead.last_message or '',
                'Cliente Satisfeito': 'Sim' if lead.is_satisfied else 'Não' if lead.is_satisfied is False else 'Não informado',
                'Dúvidas Pendentes': 'Sim' if lead.has_pending_questions else 'Não',
                'Vendedor Responsável': lead.assigned_seller or 'Não atribuído',
                'Data de Criação': lead.created_at.strftime("%d/%m/%Y %H:%M") if lead.created_at else '',
                'Última Atualização': lead.updated_at.strftime("%d/%m/%Y %H:%M") if lead.updated_at else ''
            })
        
        df = pd.DataFrame(leads_data)
        
        # Criar workbook e worksheet
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Leads"
        
        # Adicionar dados
        for r in dataframe_to_rows(df, index=False, header=True):
            ws.append(r)
        
        # Formatação
        self._format_leads_worksheet(ws)
        
        # Criar aba de estatísticas
        self._create_stats_worksheet(wb, leads)
        
        # Salvar arquivo
        wb.save(filepath)
        
        return filepath
    
    def _format_leads_worksheet(self, ws):
        """Aplica formatação à planilha de leads"""
        # Cabeçalho
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        
        for cell in ws[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center")
        
        # Auto-ajustar largura das colunas
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            
            adjusted_width = min(max_length + 2, 50)  # Máximo de 50 caracteres
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # Formatação condicional para status
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
            status_cell = row[3]  # Coluna Status
            
            if status_cell.value == "Fechado":
                status_cell.fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
            elif status_cell.value == "Perdido":
                status_cell.fill = PatternFill(start_color="FFB6C1", end_color="FFB6C1", fill_type="solid")
            elif status_cell.value == "Objeção":
                status_cell.fill = PatternFill(start_color="FFD700", end_color="FFD700", fill_type="solid")
            elif status_cell.value == "Não Respondido":
                status_cell.fill = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
    
    def _create_stats_worksheet(self, wb, leads):
        """Cria aba com estatísticas dos leads"""
        ws_stats = wb.create_sheet("Estatísticas")
        
        # Calcular estatísticas
        total_leads = len(leads)
        status_counts = {}
        objection_counts = {}
        satisfaction_counts = {'Sim': 0, 'Não': 0, 'Não informado': 0}
        
        for lead in leads:
            # Contar por status
            status = lead.status
            status_counts[status] = status_counts.get(status, 0) + 1
            
            # Contar por tipo de objeção
            if lead.objection_type:
                objection_counts[lead.objection_type] = objection_counts.get(lead.objection_type, 0) + 1
            
            # Contar satisfação
            if lead.is_satisfied is True:
                satisfaction_counts['Sim'] += 1
            elif lead.is_satisfied is False:
                satisfaction_counts['Não'] += 1
            else:
                satisfaction_counts['Não informado'] += 1
        
        # Adicionar dados de estatísticas
        ws_stats.append(['RESUMO GERAL'])
        ws_stats.append(['Total de Leads', total_leads])
        ws_stats.append([])
        
        ws_stats.append(['STATUS DOS LEADS'])
        for status, count in status_counts.items():
            percentage = (count / total_leads * 100) if total_leads > 0 else 0
            ws_stats.append([status, count, f"{percentage:.1f}%"])
        ws_stats.append([])
        
        ws_stats.append(['TIPOS DE OBJEÇÃO'])
        for objection, count in objection_counts.items():
            ws_stats.append([objection, count])
        ws_stats.append([])
        
        ws_stats.append(['SATISFAÇÃO DOS CLIENTES'])
        for satisfaction, count in satisfaction_counts.items():
            percentage = (count / total_leads * 100) if total_leads > 0 else 0
            ws_stats.append([satisfaction, count, f"{percentage:.1f}%"])
        
        # Formatação da aba de estatísticas
        self._format_stats_worksheet(ws_stats)
    
    def _format_stats_worksheet(self, ws):
        """Aplica formatação à aba de estatísticas"""
        # Títulos em negrito
        title_font = Font(bold=True, size=12)
        
        for row in ws.iter_rows():
            for cell in row:
                if cell.value in ['RESUMO GERAL', 'STATUS DOS LEADS', 'TIPOS DE OBJEÇÃO', 'SATISFAÇÃO DOS CLIENTES']:
                    cell.font = title_font
                    cell.fill = PatternFill(start_color="E6E6FA", end_color="E6E6FA", fill_type="solid")
        
        # Auto-ajustar largura das colunas
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            
            adjusted_width = min(max_length + 2, 30)
            ws.column_dimensions[column_letter].width = adjusted_width
    
    def generate_csv_export(self, filename=None):
        """Gera arquivo CSV com dados dos leads"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"leads_export_{timestamp}.csv"
        
        filepath = os.path.join(self.output_dir, filename)
        
        # Buscar todos os leads
        leads = Lead.query.all()
        
        # Converter para DataFrame
        leads_data = []
        for lead in leads:
            leads_data.append({
                'ID': lead.id,
                'Telefone': lead.phone_number,
                'Nome': lead.name or 'Não informado',
                'Status': lead.status,
                'Tipo de Objeção': lead.objection_type or '',
                'Detalhes da Objeção': lead.objection_details or '',
                'Última Mensagem': lead.last_message or '',
                'Cliente Satisfeito': 'Sim' if lead.is_satisfied else 'Não' if lead.is_satisfied is False else 'Não informado',
                'Dúvidas Pendentes': 'Sim' if lead.has_pending_questions else 'Não',
                'Vendedor Responsável': lead.assigned_seller or 'Não atribuído',
                'Data de Criação': lead.created_at.strftime("%d/%m/%Y %H:%M") if lead.created_at else '',
                'Última Atualização': lead.updated_at.strftime("%d/%m/%Y %H:%M") if lead.updated_at else ''
            })
        
        df = pd.DataFrame(leads_data)
        df.to_csv(filepath, index=False, encoding='utf-8-sig')  # utf-8-sig para compatibilidade com Excel
        
        return filepath
    
    def get_export_files(self):
        """Retorna lista de arquivos de exportação disponíveis"""
        files = []
        if os.path.exists(self.output_dir):
            for filename in os.listdir(self.output_dir):
                if filename.endswith(('.xlsx', '.csv')):
                    filepath = os.path.join(self.output_dir, filename)
                    file_info = {
                        'filename': filename,
                        'filepath': filepath,
                        'size': os.path.getsize(filepath),
                        'created': datetime.fromtimestamp(os.path.getctime(filepath)).strftime("%d/%m/%Y %H:%M")
                    }
                    files.append(file_info)
        
        return sorted(files, key=lambda x: x['created'], reverse=True)

