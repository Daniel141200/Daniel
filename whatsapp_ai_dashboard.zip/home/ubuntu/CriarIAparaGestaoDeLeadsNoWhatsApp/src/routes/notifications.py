from flask import Blueprint, request, jsonify
from src.services.notification_service import NotificationService
from src.models.lead import Lead
from datetime import datetime

notifications_bp = Blueprint('notifications', __name__)

@notifications_bp.route('/notifications/test', methods=['POST'])
def test_notification():
    """Testa o sistema de notificações"""
    try:
        data = request.get_json() or {}
        notification_type = data.get('type', 'new_lead')
        
        notification_service = NotificationService()
        
        if notification_type == 'new_lead':
            # Criar lead fictício para teste
            test_lead = type('TestLead', (), {
                'id': 999,
                'phone_number': '+5511999999999',
                'name': 'Cliente Teste',
                'last_message': 'Olá, gostaria de saber mais sobre seus produtos.',
                'created_at': datetime.now(),
                'assigned_seller': 'Vendedor Teste'
            })()
            
            result = notification_service.send_new_lead_notification(test_lead)
            
        elif notification_type == 'status_change':
            test_lead = type('TestLead', (), {
                'id': 999,
                'phone_number': '+5511999999999',
                'name': 'Cliente Teste',
                'assigned_seller': 'Vendedor Teste'
            })()
            
            result = notification_service.send_status_change_notification(
                test_lead, 'Não Respondido', 'Respondido'
            )
            
        elif notification_type == 'objection':
            test_lead = type('TestLead', (), {
                'id': 999,
                'phone_number': '+5511999999999',
                'name': 'Cliente Teste',
                'objection_type': 'Preço',
                'objection_details': 'Achou o valor muito alto',
                'last_message': 'O preço está muito caro para mim.',
                'assigned_seller': 'Vendedor Teste'
            })()
            
            result = notification_service.send_objection_notification(test_lead)
            
        elif notification_type == 'satisfaction':
            test_lead = type('TestLead', (), {
                'id': 999,
                'phone_number': '+5511999999999',
                'name': 'Cliente Teste',
                'assigned_seller': 'Vendedor Teste'
            })()
            
            is_satisfied = data.get('satisfied', True)
            result = notification_service.send_satisfaction_alert(test_lead, is_satisfied)
            
        elif notification_type == 'pending_questions':
            test_lead = type('TestLead', (), {
                'id': 999,
                'phone_number': '+5511999999999',
                'name': 'Cliente Teste',
                'last_message': 'Ainda tenho algumas dúvidas sobre o produto.',
                'assigned_seller': 'Vendedor Teste'
            })()
            
            result = notification_service.send_pending_questions_alert(test_lead)
            
        elif notification_type == 'daily_summary':
            result = notification_service.send_daily_summary()
            
        else:
            return jsonify({'error': 'Tipo de notificação inválido'}), 400
        
        if result:
            return jsonify({
                'status': 'success',
                'message': f'Notificação de teste ({notification_type}) enviada com sucesso'
            }), 200
        else:
            return jsonify({
                'status': 'error',
                'message': 'Falha ao enviar notificação de teste'
            }), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@notifications_bp.route('/notifications/send-daily-summary', methods=['POST'])
def send_daily_summary():
    """Envia resumo diário manualmente"""
    try:
        notification_service = NotificationService()
        result = notification_service.send_daily_summary()
        
        if result:
            return jsonify({
                'status': 'success',
                'message': 'Resumo diário enviado com sucesso'
            }), 200
        else:
            return jsonify({
                'status': 'error',
                'message': 'Falha ao enviar resumo diário'
            }), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@notifications_bp.route('/notifications/settings', methods=['GET'])
def get_notification_settings():
    """Obtém configurações de notificação"""
    try:
        # Retornar configurações atuais (pode ser expandido para incluir preferências do usuário)
        settings = {
            'email_enabled': True,  # Verificar se email está configurado
            'slack_enabled': False,  # Verificar se Slack está configurado
            'notification_types': {
                'new_lead': True,
                'status_change': True,
                'objection': True,
                'satisfaction': True,
                'pending_questions': True,
                'daily_summary': True
            }
        }
        
        return jsonify(settings), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@notifications_bp.route('/notifications/settings', methods=['PUT'])
def update_notification_settings():
    """Atualiza configurações de notificação"""
    try:
        data = request.get_json()
        
        # Aqui você pode implementar a lógica para salvar as configurações
        # Por exemplo, em um arquivo de configuração ou banco de dados
        
        return jsonify({
            'status': 'success',
            'message': 'Configurações atualizadas com sucesso'
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@notifications_bp.route('/notifications/trigger', methods=['POST'])
def trigger_notification():
    """Dispara notificação baseada em evento específico"""
    try:
        data = request.get_json()
        lead_id = data.get('lead_id')
        event_type = data.get('event_type')
        
        if not lead_id or not event_type:
            return jsonify({'error': 'lead_id e event_type são obrigatórios'}), 400
        
        lead = Lead.query.get_or_404(lead_id)
        notification_service = NotificationService()
        
        result = False
        
        if event_type == 'new_lead':
            result = notification_service.send_new_lead_notification(lead)
            
        elif event_type == 'status_change':
            old_status = data.get('old_status', 'Desconhecido')
            result = notification_service.send_status_change_notification(
                lead, old_status, lead.status
            )
            
        elif event_type == 'objection':
            result = notification_service.send_objection_notification(lead)
            
        elif event_type == 'satisfaction':
            result = notification_service.send_satisfaction_alert(
                lead, lead.is_satisfied
            )
            
        elif event_type == 'pending_questions':
            result = notification_service.send_pending_questions_alert(lead)
        
        if result:
            return jsonify({
                'status': 'success',
                'message': f'Notificação ({event_type}) enviada com sucesso'
            }), 200
        else:
            return jsonify({
                'status': 'error',
                'message': 'Falha ao enviar notificação'
            }), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

