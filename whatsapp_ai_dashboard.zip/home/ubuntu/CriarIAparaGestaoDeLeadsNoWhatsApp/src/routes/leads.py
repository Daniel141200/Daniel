from flask import Blueprint, request, jsonify
from src.models.lead import Lead, Message, db
from datetime import datetime
import openai
import os

leads_bp = Blueprint('leads', __name__)

def analyze_message_with_ai(message_content):
    """Analisa a mensagem usando IA para identificar intenção e sentimento"""
    try:
        client = openai.OpenAI()
        
        prompt = f"""
        Analise a seguinte mensagem de um cliente e forneça:
        1. Intenção (interesse, dúvida, objeção, satisfação, reclamação)
        2. Sentimento (positivo, neutro, negativo)
        3. Tipo de objeção (se houver): preço, prazo, produto, outro
        4. Se o cliente parece satisfeito (sim/não/incerto)
        5. Se há dúvidas pendentes (sim/não)
        
        Mensagem: "{message_content}"
        
        Responda em formato JSON:
        {{
            "intencao": "...",
            "sentimento": "...",
            "tipo_objecao": "...",
            "satisfeito": "...",
            "duvidas_pendentes": "..."
        }}
        """
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200
        )
        
        return response.choices[0].message.content
    except Exception as e:
        return f"Erro na análise: {str(e)}"

@leads_bp.route('/webhook', methods=['POST'])
def whatsapp_webhook():
    """Webhook para receber mensagens do WhatsApp"""
    try:
        data = request.get_json()
        
        # Extrair informações da mensagem do WhatsApp
        # Estrutura pode variar dependendo da API específica
        phone_number = data.get('from', '')
        message_content = data.get('text', {}).get('body', '')
        
        if not phone_number or not message_content:
            return jsonify({'error': 'Dados incompletos'}), 400
        
        # Buscar ou criar lead
        lead = Lead.query.filter_by(phone_number=phone_number).first()
        if not lead:
            lead = Lead(phone_number=phone_number)
            db.session.add(lead)
            db.session.flush()  # Para obter o ID
        
        # Criar nova mensagem
        message = Message(
            lead_id=lead.id,
            message_content=message_content,
            is_from_customer=True
        )
        
        # Analisar mensagem com IA
        ai_analysis = analyze_message_with_ai(message_content)
        message.ai_analysis = ai_analysis
        
        # Atualizar lead baseado na análise
        lead.last_message = message_content
        lead.updated_at = datetime.utcnow()
        
        # Aqui você pode implementar lógica para atualizar status baseado na análise da IA
        # Por exemplo, se a análise indica objeção, atualizar o status
        
        db.session.add(message)
        db.session.commit()
        
        return jsonify({'status': 'success', 'lead_id': lead.id}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/leads', methods=['GET'])
def get_leads():
    """Obter todos os leads"""
    try:
        leads = Lead.query.all()
        return jsonify([lead.to_dict() for lead in leads]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/leads/<int:lead_id>', methods=['GET'])
def get_lead(lead_id):
    """Obter um lead específico"""
    try:
        lead = Lead.query.get_or_404(lead_id)
        return jsonify(lead.to_dict()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/leads/<int:lead_id>', methods=['PUT'])
def update_lead(lead_id):
    """Atualizar um lead"""
    try:
        lead = Lead.query.get_or_404(lead_id)
        data = request.get_json()
        
        # Atualizar campos permitidos
        if 'name' in data:
            lead.name = data['name']
        if 'status' in data:
            lead.status = data['status']
        if 'objection_type' in data:
            lead.objection_type = data['objection_type']
        if 'objection_details' in data:
            lead.objection_details = data['objection_details']
        if 'is_satisfied' in data:
            lead.is_satisfied = data['is_satisfied']
        if 'has_pending_questions' in data:
            lead.has_pending_questions = data['has_pending_questions']
        if 'assigned_seller' in data:
            lead.assigned_seller = data['assigned_seller']
        
        lead.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify(lead.to_dict()), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/leads/<int:lead_id>/messages', methods=['GET'])
def get_lead_messages(lead_id):
    """Obter mensagens de um lead"""
    try:
        messages = Message.query.filter_by(lead_id=lead_id).order_by(Message.timestamp).all()
        return jsonify([message.to_dict() for message in messages]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/leads/stats', methods=['GET'])
def get_leads_stats():
    """Obter estatísticas dos leads"""
    try:
        total_leads = Lead.query.count()
        not_responded = Lead.query.filter_by(status='Não Respondido').count()
        responded = Lead.query.filter_by(status='Respondido').count()
        quote_sent = Lead.query.filter_by(status='Orçamento Enviado').count()
        objections = Lead.query.filter_by(status='Objeção').count()
        closed = Lead.query.filter_by(status='Fechado').count()
        lost = Lead.query.filter_by(status='Perdido').count()
        
        stats = {
            'total_leads': total_leads,
            'not_responded': not_responded,
            'responded': responded,
            'quote_sent': quote_sent,
            'objections': objections,
            'closed': closed,
            'lost': lost
        }
        
        return jsonify(stats), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

