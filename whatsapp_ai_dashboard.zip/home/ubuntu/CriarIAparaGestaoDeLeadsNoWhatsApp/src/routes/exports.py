from flask import Blueprint, request, jsonify, send_file
from src.services.spreadsheet_service import SpreadsheetService
import os

exports_bp = Blueprint('exports', __name__)

@exports_bp.route('/export/excel', methods=['POST'])
def export_excel():
    """Gera e retorna planilha Excel com dados dos leads"""
    try:
        data = request.get_json() or {}
        filename = data.get('filename')
        
        spreadsheet_service = SpreadsheetService()
        filepath = spreadsheet_service.generate_leads_excel(filename)
        
        return jsonify({
            'status': 'success',
            'message': 'Planilha Excel gerada com sucesso',
            'filepath': filepath,
            'filename': os.path.basename(filepath)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@exports_bp.route('/export/csv', methods=['POST'])
def export_csv():
    """Gera e retorna arquivo CSV com dados dos leads"""
    try:
        data = request.get_json() or {}
        filename = data.get('filename')
        
        spreadsheet_service = SpreadsheetService()
        filepath = spreadsheet_service.generate_csv_export(filename)
        
        return jsonify({
            'status': 'success',
            'message': 'Arquivo CSV gerado com sucesso',
            'filepath': filepath,
            'filename': os.path.basename(filepath)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@exports_bp.route('/export/download/<filename>', methods=['GET'])
def download_export(filename):
    """Faz download de arquivo de exportação"""
    try:
        spreadsheet_service = SpreadsheetService()
        filepath = os.path.join(spreadsheet_service.output_dir, filename)
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'Arquivo não encontrado'}), 404
        
        return send_file(filepath, as_attachment=True, download_name=filename)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@exports_bp.route('/export/files', methods=['GET'])
def list_export_files():
    """Lista arquivos de exportação disponíveis"""
    try:
        spreadsheet_service = SpreadsheetService()
        files = spreadsheet_service.get_export_files()
        
        return jsonify({
            'status': 'success',
            'files': files
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@exports_bp.route('/export/delete/<filename>', methods=['DELETE'])
def delete_export_file(filename):
    """Deleta arquivo de exportação"""
    try:
        spreadsheet_service = SpreadsheetService()
        filepath = os.path.join(spreadsheet_service.output_dir, filename)
        
        if not os.path.exists(filepath):
            return jsonify({'error': 'Arquivo não encontrado'}), 404
        
        os.remove(filepath)
        
        return jsonify({
            'status': 'success',
            'message': 'Arquivo deletado com sucesso'
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

