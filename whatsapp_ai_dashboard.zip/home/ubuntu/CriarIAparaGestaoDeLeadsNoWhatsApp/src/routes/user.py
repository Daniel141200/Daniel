from flask import Blueprint

user_bp = Blueprint("user_bp", __name__)

# Adicione suas rotas de usuário aqui, se houver


