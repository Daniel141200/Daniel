from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Lead(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    phone_number = db.Column(db.String(20), nullable=False)
    name = db.Column(db.String(100), nullable=True)
    status = db.Column(db.String(50), default='Não Respondido')
    # Status possíveis: Não Respondido, Respondido, Orçamento Enviado, Objeção, Fechado, Perdido
    objection_type = db.Column(db.String(100), nullable=True)
    # Tipos de objeção: Preço, Prazo de Entrega, Produto Caro, Outro
    objection_details = db.Column(db.Text, nullable=True)
    last_message = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_satisfied = db.Column(db.Boolean, default=None)
    has_pending_questions = db.Column(db.Boolean, default=False)
    assigned_seller = db.Column(db.String(100), nullable=True)
    
    def __repr__(self):
        return f'<Lead {self.phone_number} - {self.status}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'phone_number': self.phone_number,
            'name': self.name,
            'status': self.status,
            'objection_type': self.objection_type,
            'objection_details': self.objection_details,
            'last_message': self.last_message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'is_satisfied': self.is_satisfied,
            'has_pending_questions': self.has_pending_questions,
            'assigned_seller': self.assigned_seller
        }

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lead_id = db.Column(db.Integer, db.ForeignKey('lead.id'), nullable=False)
    message_content = db.Column(db.Text, nullable=False)
    is_from_customer = db.Column(db.Boolean, default=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    ai_analysis = db.Column(db.Text, nullable=True)  # Análise da IA sobre a mensagem
    
    lead = db.relationship('Lead', backref=db.backref('messages', lazy=True))
    
    def __repr__(self):
        return f'<Message {self.id} - Lead {self.lead_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'lead_id': self.lead_id,
            'message_content': self.message_content,
            'is_from_customer': self.is_from_customer,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'ai_analysis': self.ai_analysis
        }

