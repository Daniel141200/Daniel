# Guia de Integração com WhatsApp Business API

## 📋 Visão Geral

Este guia detalha como integrar o sistema com a WhatsApp Business API para receber mensagens automaticamente e processar leads em tempo real.

## 🔑 Pré-requisitos

1. **Conta WhatsApp Business** verificada
2. **Acesso à Meta for Developers** (developers.facebook.com)
3. **Número de telefone** dedicado para negócios
4. **Servidor com HTTPS** (para produção)

## 🚀 Configuração Passo a Passo

### Etapa 1: Configurar WhatsApp Business Account

1. **Acesse Meta for Developers**:
   - Vá para https://developers.facebook.com/
   - Faça login com sua conta Meta/Facebook

2. **Crie um App**:
   - Clique em "Create App"
   - Selecione "Business"
   - Preencha os dados do app

3. **Adicione WhatsApp Product**:
   - No dashboard do app, clique em "Add Product"
   - Selecione "WhatsApp"
   - Configure as permissões necessárias

### Etapa 2: Configurar Webhook

1. **URL do Webhook**:
   ```
   https://seu-dominio.com/api/webhook
   ```

2. **Token de Verificação**:
   - Gere um token seguro (ex: `meu_token_secreto_123`)
   - Configure no código se necessário

3. **Eventos para Subscrever**:
   - `messages` - Para receber mensagens
   - `message_deliveries` - Para status de entrega

### Etapa 3: Configurar Servidor

#### Para Desenvolvimento (ngrok)
```bash
# Instale ngrok
npm install -g ngrok

# Execute seu sistema
python src/main.py

# Em outro terminal, exponha a porta
ngrok http 5000

# Use a URL HTTPS gerada (ex: https://abc123.ngrok.io)
```

#### Para Produção
```bash
# Configure HTTPS com Let's Encrypt ou similar
# Certifique-se de que o servidor está acessível na porta 443/80
```

### Etapa 4: Testar Webhook

1. **Verificação Automática**:
   O WhatsApp enviará uma requisição GET para verificar o webhook:
   ```
   GET /api/webhook?hub.mode=subscribe&hub.challenge=CHALLENGE&hub.verify_token=TOKEN
   ```

2. **Resposta Esperada**:
   O sistema deve retornar o valor de `hub.challenge`

3. **Teste Manual**:
   ```bash
   curl -X POST https://seu-dominio.com/api/webhook \
     -H "Content-Type: application/json" \
     -d '{
       "from": "+5511999999999",
       "text": {
         "body": "Teste de mensagem"
       }
     }'
   ```

## 📨 Formato de Mensagens

### Mensagem Recebida (Webhook)
```json
{
  "object": "whatsapp_business_account",
  "entry": [
    {
      "id": "WHATSAPP_BUSINESS_ACCOUNT_ID",
      "changes": [
        {
          "value": {
            "messaging_product": "whatsapp",
            "metadata": {
              "display_phone_number": "15551234567",
              "phone_number_id": "123456789"
            },
            "contacts": [
              {
                "profile": {
                  "name": "João Silva"
                },
                "wa_id": "5511999999999"
              }
            ],
            "messages": [
              {
                "from": "5511999999999",
                "id": "wamid.ABC123",
                "timestamp": "1690000000",
                "text": {
                  "body": "Olá, gostaria de saber sobre seus produtos"
                },
                "type": "text"
              }
            ]
          },
          "field": "messages"
        }
      ]
    }
  ]
}
```

### Processamento no Sistema

O sistema processa a mensagem da seguinte forma:

1. **Extração de Dados**:
   ```python
   phone_number = data['entry'][0]['changes'][0]['value']['messages'][0]['from']
   message_text = data['entry'][0]['changes'][0]['value']['messages'][0]['text']['body']
   contact_name = data['entry'][0]['changes'][0]['value']['contacts'][0]['profile']['name']
   ```

2. **Criação/Atualização do Lead**:
   - Busca lead existente pelo telefone
   - Cria novo lead se não existir
   - Atualiza informações com nova mensagem

3. **Análise de IA**:
   - Envia mensagem para OpenAI
   - Analisa intenção, sentimento e objeções
   - Atualiza campos do lead automaticamente

4. **Notificações**:
   - Envia notificação para vendedores
   - Dispara alertas baseados na análise

## 🔧 Configurações Avançadas

### Personalizar Análise de IA

Edite o prompt em `src/routes/leads.py`:

```python
prompt = f"""
Analise a seguinte mensagem de um cliente e forneça:
1. Intenção (interesse, dúvida, objeção, satisfação, reclamação)
2. Sentimento (positivo, neutro, negativo)
3. Tipo de objeção (se houver): preço, prazo, produto, outro
4. Se o cliente parece satisfeito (sim/não/incerto)
5. Se há dúvidas pendentes (sim/não)

Contexto do negócio: [ADICIONE SEU CONTEXTO AQUI]

Mensagem: "{message_content}"

Responda em formato JSON:
{{
    "intencao": "...",
    "sentimento": "...",
    "tipo_objecao": "...",
    "satisfeito": "...",
    "duvidas_pendentes": "..."
}}
"""
```

### Configurar Múltiplos Números

Para gerenciar múltiplos números WhatsApp:

```python
# Em src/models/lead.py, adicione:
whatsapp_number = db.Column(db.String(20), nullable=True)

# No webhook, identifique o número de destino:
destination_number = data['entry'][0]['changes'][0]['value']['metadata']['display_phone_number']
```

### Implementar Rate Limiting

Para evitar spam e controlar uso da API:

```python
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

@leads_bp.route('/webhook', methods=['POST'])
@limiter.limit("10 per minute")
def whatsapp_webhook():
    # Código do webhook
```

## 🔒 Segurança

### Validação de Webhook

Implemente validação de assinatura:

```python
import hmac
import hashlib

def verify_webhook_signature(payload, signature, secret):
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(signature, expected_signature)
```

### Filtros de Segurança

```python
# Validar números de telefone
import re

def is_valid_phone(phone):
    pattern = r'^\+?[1-9]\d{1,14}$'
    return re.match(pattern, phone) is not None

# Filtrar conteúdo malicioso
def sanitize_message(message):
    # Remover caracteres perigosos
    # Limitar tamanho da mensagem
    return message[:1000]  # Máximo 1000 caracteres
```

## 📊 Monitoramento

### Logs de Webhook

Adicione logs detalhados:

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@leads_bp.route('/webhook', methods=['POST'])
def whatsapp_webhook():
    try:
        data = request.get_json()
        logger.info(f"Webhook recebido: {data}")
        
        # Processamento...
        
        logger.info(f"Lead processado: {lead.id}")
        return jsonify({'status': 'success'})
        
    except Exception as e:
        logger.error(f"Erro no webhook: {e}")
        return jsonify({'error': str(e)}), 500
```

### Métricas de Performance

```python
import time
from functools import wraps

def measure_time(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        logger.info(f"{func.__name__} executado em {end-start:.2f}s")
        return result
    return wrapper

@measure_time
def analyze_message_with_ai(message_content):
    # Código da análise
```

## 🧪 Testes

### Teste de Webhook Local

```python
import requests

def test_webhook():
    url = "http://localhost:5000/api/webhook"
    payload = {
        "from": "+5511999999999",
        "text": {
            "body": "Teste de mensagem automática"
        }
    }
    
    response = requests.post(url, json=payload)
    print(f"Status: {response.status_code}")
    print(f"Resposta: {response.json()}")

# Execute o teste
test_webhook()
```

### Simulador de Mensagens

Crie um script para simular diferentes tipos de mensagem:

```python
# test_messages.py
messages = [
    "Olá, gostaria de saber sobre seus produtos",
    "O preço está muito caro para mim",
    "Quando vocês conseguem entregar?",
    "Estou muito satisfeito com o atendimento",
    "Ainda tenho algumas dúvidas sobre o produto"
]

for msg in messages:
    test_webhook_with_message(msg)
    time.sleep(2)  # Aguardar 2 segundos entre mensagens
```

## 🚀 Deploy em Produção

### Usando Docker

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY src/ ./src/
EXPOSE 5000

CMD ["python", "src/main.py"]
```

### Usando Heroku

```bash
# Criar Procfile
echo "web: python src/main.py" > Procfile

# Deploy
heroku create seu-app-whatsapp
git push heroku main
```

### Usando AWS/DigitalOcean

1. **Configure servidor** com Ubuntu/CentOS
2. **Instale dependências**:
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip nginx
   ```

3. **Configure Nginx** como proxy reverso
4. **Use Gunicorn** para produção:
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
   ```

## 📞 Suporte e Troubleshooting

### Problemas Comuns

1. **Webhook não recebe mensagens**:
   - Verifique se URL está acessível externamente
   - Confirme HTTPS em produção
   - Verifique logs do servidor

2. **Erro de autenticação**:
   - Confirme token de verificação
   - Verifique permissões do app no Meta

3. **Mensagens duplicadas**:
   - Implemente deduplicação por message_id
   - Configure timeout adequado

4. **Rate limit excedido**:
   - Implemente fila de processamento
   - Configure retry com backoff

### Logs Úteis

```bash
# Logs do sistema
tail -f /var/log/whatsapp_ai.log

# Logs do Nginx (se usando)
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log

# Logs do aplicativo
python src/main.py 2>&1 | tee app.log
```

---

**Integração WhatsApp configurada com sucesso!** 🎉

Para mais detalhes, consulte a [documentação oficial do WhatsApp Business API](https://developers.facebook.com/docs/whatsapp/).

