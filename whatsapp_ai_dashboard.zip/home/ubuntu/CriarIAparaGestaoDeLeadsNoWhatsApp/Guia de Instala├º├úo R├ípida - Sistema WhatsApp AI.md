# Guia de Instalação Rápida - Sistema WhatsApp AI

## 🚀 Instalação em 5 Minutos

### Pré-requisitos
- Python 3.11+
- Conta OpenAI (para API key)

### Passo 1: Preparar Ambiente
```bash
cd whatsapp_ai_system
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
```

### Passo 2: Instalar Dependências
```bash
pip install -r requirements.txt
```

### Passo 3: Configurar API Key
```bash
# Linux/Mac
export OPENAI_API_KEY="sua_api_key_aqui"

# Windows
set OPENAI_API_KEY=sua_api_key_aqui
```

### Passo 4: Executar Sistema
```bash
python src/main.py
```

### Passo 5: Acessar Dashboard
Abra seu navegador em: `http://localhost:5000`

## ⚙️ Configurações Opcionais

### Email (Notificações)
```bash
export SMTP_SERVER="smtp.gmail.com"
export SMTP_PORT="587"
export EMAIL_USER="seu_email@gmail.com"
export EMAIL_PASSWORD="sua_senha_app"
```

### Slack (Notificações)
```bash
export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/..."
```

## 🔧 Teste do Sistema

1. **Acesse o dashboard**: `http://localhost:5000`
2. **Teste notificações**: Use a rota `/api/notifications/test`
3. **Simule webhook**: Envie POST para `/api/webhook`

## 📱 Integração WhatsApp

### Para Desenvolvimento (Teste)
Use ferramentas como ngrok para expor localhost:
```bash
ngrok http 5000
# Use a URL gerada como webhook no WhatsApp
```

### Para Produção
1. Configure domínio com HTTPS
2. Configure webhook: `https://seu-dominio.com/api/webhook`
3. Configure permissões no WhatsApp Business API

## 🐛 Problemas Comuns

### Erro: ModuleNotFoundError
```bash
pip install -r requirements.txt
```

### Erro: OpenAI API
Verifique se a API key está configurada:
```bash
echo $OPENAI_API_KEY
```

### Erro: Porta em Uso
Mude a porta no arquivo `src/main.py`:
```python
app.run(host='0.0.0.0', port=8000, debug=True)
```

## 📞 Suporte

- **Documentação completa**: Veja `README.md`
- **Logs**: Verifique terminal onde executou `python src/main.py`
- **Teste de APIs**: Use Postman ou curl para testar endpoints

---

**Sistema pronto para uso!** 🎉

