# Sistema de IA para WhatsApp - Gerenciamento de Leads

**Autor:** Manus AI  
**Data:** 29 de Julho de 2025  
**Versão:** 1.0.0

## Índice

1. [Visão Geral](#visão-geral)
2. [Funcionalidades](#funcionalidades)
3. [Arquitetura do Sistema](#arquitetura-do-sistema)
4. [Instalação e Configuração](#instalação-e-configuração)
5. [Guia de Uso](#guia-de-uso)
6. [API Reference](#api-reference)
7. [Integração com WhatsApp](#integração-com-whatsapp)
8. [Sistema de Notificações](#sistema-de-notificações)
9. [Exportação de Dados](#exportação-de-dados)
10. [Troubleshooting](#troubleshooting)
11. [Contribuição](#contribuição)

## Visão Geral

O Sistema de IA para WhatsApp é uma solução completa para gerenciamento automatizado de leads recebidos via WhatsApp Business. O sistema utiliza inteligência artificial para analisar mensagens, classificar leads, identificar objeções e automatizar o processo de acompanhamento de vendas.

### Principais Benefícios

- **Automação Inteligente**: Análise automática de mensagens usando IA para identificar intenções e sentimentos
- **Gestão Centralizada**: Dashboard web para visualização e gerenciamento de todos os leads
- **Notificações em Tempo Real**: Alertas automáticos para vendedores sobre novos leads e mudanças de status
- **Exportação de Dados**: Geração automática de planilhas Excel e CSV para análise
- **Rastreamento Completo**: Histórico completo de interações com cada lead

## Funcionalidades

### 🤖 Inteligência Artificial
- Análise automática de mensagens para identificar:
  - Intenção do cliente (interesse, dúvida, objeção, satisfação)
  - Sentimento (positivo, neutro, negativo)
  - Tipo de objeção (preço, prazo, produto, outro)
  - Nível de satisfação do cliente
  - Presença de dúvidas pendentes

### 📊 Dashboard de Controle
- Visualização em tempo real de estatísticas de leads
- Filtros avançados por status, vendedor e busca textual
- Interface responsiva para desktop e mobile
- Edição inline de informações dos leads
- Histórico completo de mensagens

### 🔔 Sistema de Notificações
- Notificações por email para vendedores
- Integração opcional com Slack
- Alertas automáticos para:
  - Novos leads recebidos
  - Mudanças de status
  - Objeções identificadas
  - Clientes insatisfeitos
  - Dúvidas pendentes
  - Resumo diário

### 📈 Exportação e Relatórios
- Geração automática de planilhas Excel com formatação
- Exportação em CSV para análise externa
- Estatísticas detalhadas por status e vendedor
- Relatórios de desempenho

### 🔗 Integração WhatsApp
- Webhook para recebimento de mensagens
- Compatível com WhatsApp Business API
- Processamento em tempo real de mensagens
- Armazenamento seguro de dados

## Arquitetura do Sistema

### Tecnologias Utilizadas

**Backend:**
- **Flask** (Python) - Framework web principal
- **SQLAlchemy** - ORM para banco de dados
- **SQLite** - Banco de dados (pode ser migrado para PostgreSQL/MySQL)
- **OpenAI API** - Inteligência artificial para análise de mensagens

**Frontend:**
- **HTML5/CSS3** - Estrutura e estilização
- **JavaScript (Vanilla)** - Interatividade
- **Tailwind CSS** - Framework CSS para design responsivo
- **Font Awesome** - Ícones

**Bibliotecas Python:**
- **pandas** - Manipulação de dados
- **openpyxl** - Geração de planilhas Excel
- **requests** - Requisições HTTP
- **flask-cors** - Suporte a CORS

### Estrutura do Projeto

```
whatsapp_ai_system/
├── src/
│   ├── models/
│   │   ├── user.py          # Modelo de usuário
│   │   └── lead.py          # Modelos de Lead e Message
│   ├── routes/
│   │   ├── user.py          # Rotas de usuário
│   │   ├── leads.py         # Rotas de leads
│   │   ├── exports.py       # Rotas de exportação
│   │   └── notifications.py # Rotas de notificações
│   ├── services/
│   │   ├── spreadsheet_service.py    # Serviço de planilhas
│   │   └── notification_service.py   # Serviço de notificações
│   ├── static/
│   │   ├── index.html       # Interface principal
│   │   └── script.js        # JavaScript do frontend
│   ├── database/
│   │   └── app.db          # Banco de dados SQLite
│   └── main.py             # Aplicação principal
├── exports/                # Arquivos de exportação
├── venv/                   # Ambiente virtual Python
├── requirements.txt        # Dependências Python
└── README.md              # Esta documentação
```

## Instalação e Configuração

### Pré-requisitos

- Python 3.11 ou superior
- pip (gerenciador de pacotes Python)
- Conta OpenAI com API key (para análise de IA)
- Acesso ao WhatsApp Business API (opcional para produção)

### Instalação Passo a Passo

1. **Clone ou extraia o projeto:**
```bash
cd whatsapp_ai_system
```

2. **Ative o ambiente virtual:**
```bash
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
```

3. **Instale as dependências:**
```bash
pip install -r requirements.txt
```

4. **Configure as variáveis de ambiente:**
```bash
# Crie um arquivo .env na raiz do projeto
export OPENAI_API_KEY="sua_api_key_aqui"
export OPENAI_API_BASE="https://api.openai.com/v1"

# Configurações de email (opcional)
export SMTP_SERVER="smtp.gmail.com"
export SMTP_PORT="587"
export EMAIL_USER="seu_email@gmail.com"
export EMAIL_PASSWORD="sua_senha_app"

# Configurações Slack (opcional)
export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/..."
```

5. **Execute a aplicação:**
```bash
python src/main.py
```

6. **Acesse o dashboard:**
Abra seu navegador e vá para `http://localhost:5000`

### Configuração do WhatsApp Business API

Para integração completa com WhatsApp, você precisará:

1. **Configurar Webhook:**
   - URL: `http://seu-dominio.com/api/webhook`
   - Método: POST
   - Verificação: Implementada na rota `/api/webhook`

2. **Configurar Permissões:**
   - `messages` - Para receber mensagens
   - `message_deliveries` - Para status de entrega

3. **Testar Integração:**
   - Use a rota `/api/notifications/test` para testar notificações
   - Monitore logs para verificar recebimento de mensagens

## Guia de Uso

### Dashboard Principal

O dashboard é a interface central para gerenciar seus leads. Ele oferece:

#### Estatísticas em Tempo Real
- **Total de Leads**: Número total de leads no sistema
- **Não Respondidos**: Leads aguardando primeira resposta
- **Fechados**: Vendas concluídas com sucesso
- **Objeções**: Leads com objeções identificadas

#### Filtros e Busca
- **Filtro por Status**: Filtre leads por status específico
- **Filtro por Vendedor**: Visualize leads de vendedor específico
- **Busca Textual**: Busque por nome ou telefone

#### Gerenciamento de Leads
- **Edição Inline**: Clique em "Editar" para modificar informações
- **Histórico de Mensagens**: Visualize todas as interações
- **Atualização de Status**: Altere status conforme progresso da venda

### Fluxo de Trabalho Recomendado

1. **Recebimento de Lead:**
   - Sistema recebe mensagem via webhook
   - IA analisa automaticamente o conteúdo
   - Notificação é enviada para vendedor

2. **Primeira Resposta:**
   - Vendedor acessa dashboard
   - Visualiza análise da IA
   - Responde ao cliente via WhatsApp
   - Atualiza status para "Respondido"

3. **Acompanhamento:**
   - Sistema monitora novas mensagens
   - IA identifica objeções ou satisfação
   - Vendedor recebe alertas automáticos

4. **Fechamento:**
   - Status atualizado para "Fechado" ou "Perdido"
   - Dados exportados para análise
   - Métricas atualizadas no dashboard

### Gerenciamento de Status

O sistema utiliza os seguintes status para leads:

| Status | Descrição | Ação Recomendada |
|--------|-----------|------------------|
| **Não Respondido** | Lead recém-chegado | Responder o mais rápido possível |
| **Respondido** | Primeira resposta enviada | Preparar orçamento se necessário |
| **Orçamento Enviado** | Proposta comercial enviada | Acompanhar resposta do cliente |
| **Objeção** | Cliente apresentou objeção | Trabalhar a objeção identificada |
| **Fechado** | Venda concluída | Parabéns! Venda realizada |
| **Perdido** | Lead não convertido | Analisar motivos da perda |

## API Reference

### Endpoints de Leads

#### GET /api/leads
Retorna lista de todos os leads.

**Resposta:**
```json
[
  {
    "id": 1,
    "phone_number": "+5511999999999",
    "name": "João Silva",
    "status": "Não Respondido",
    "objection_type": null,
    "objection_details": null,
    "last_message": "Olá, gostaria de saber sobre seus produtos",
    "created_at": "2025-07-29T10:30:00",
    "updated_at": "2025-07-29T10:30:00",
    "is_satisfied": null,
    "has_pending_questions": false,
    "assigned_seller": null
  }
]
```

#### GET /api/leads/{id}
Retorna dados de um lead específico.

#### PUT /api/leads/{id}
Atualiza dados de um lead.

**Payload:**
```json
{
  "name": "João Silva",
  "status": "Respondido",
  "objection_type": "Preço",
  "objection_details": "Achou o valor alto",
  "is_satisfied": true,
  "has_pending_questions": false,
  "assigned_seller": "Vendedor 1"
}
```

#### POST /api/webhook
Webhook para receber mensagens do WhatsApp.

**Payload esperado:**
```json
{
  "from": "+5511999999999",
  "text": {
    "body": "Mensagem do cliente"
  }
}
```

### Endpoints de Exportação

#### POST /api/export/excel
Gera planilha Excel com dados dos leads.

#### POST /api/export/csv
Gera arquivo CSV com dados dos leads.

#### GET /api/export/download/{filename}
Faz download de arquivo de exportação.

### Endpoints de Notificações

#### POST /api/notifications/test
Testa sistema de notificações.

**Payload:**
```json
{
  "type": "new_lead",
  "satisfied": true
}
```

#### POST /api/notifications/trigger
Dispara notificação para lead específico.

**Payload:**
```json
{
  "lead_id": 1,
  "event_type": "objection",
  "old_status": "Respondido"
}
```

## Integração com WhatsApp

### Configuração do Webhook

1. **Configure a URL do webhook** no painel do WhatsApp Business:
   ```
   https://seu-dominio.com/api/webhook
   ```

2. **Token de Verificação**: Configure um token seguro para validação

3. **Eventos Suportados**:
   - `messages` - Mensagens recebidas
   - `message_deliveries` - Status de entrega

### Estrutura de Mensagem

O sistema espera mensagens no formato padrão do WhatsApp Business API:

```json
{
  "object": "whatsapp_business_account",
  "entry": [
    {
      "id": "WHATSAPP_BUSINESS_ACCOUNT_ID",
      "changes": [
        {
          "value": {
            "messaging_product": "whatsapp",
            "metadata": {
              "display_phone_number": "PHONE_NUMBER",
              "phone_number_id": "PHONE_NUMBER_ID"
            },
            "contacts": [
              {
                "profile": {
                  "name": "CUSTOMER_NAME"
                },
                "wa_id": "CUSTOMER_PHONE_NUMBER"
              }
            ],
            "messages": [
              {
                "from": "CUSTOMER_PHONE_NUMBER",
                "id": "MESSAGE_ID",
                "timestamp": "TIMESTAMP",
                "text": {
                  "body": "CUSTOMER_MESSAGE"
                },
                "type": "text"
              }
            ]
          },
          "field": "messages"
        }
      ]
    }
  ]
}
```

### Análise de IA

Para cada mensagem recebida, o sistema:

1. **Extrai o conteúdo** da mensagem
2. **Envia para OpenAI** com prompt específico
3. **Analisa a resposta** em formato JSON
4. **Atualiza o lead** com informações extraídas
5. **Dispara notificações** se necessário

Exemplo de análise retornada pela IA:

```json
{
  "intencao": "objecao",
  "sentimento": "negativo",
  "tipo_objecao": "preco",
  "satisfeito": "nao",
  "duvidas_pendentes": "sim"
}
```

## Sistema de Notificações

### Tipos de Notificação

1. **Novo Lead**
   - Disparada quando um novo lead é criado
   - Inclui informações básicas do cliente
   - Enviada para todos os vendedores

2. **Mudança de Status**
   - Disparada quando status do lead muda
   - Inclui sugestões de ação baseadas no novo status
   - Enviada para vendedor responsável

3. **Objeção Identificada**
   - Disparada quando IA identifica objeção
   - Inclui tipo de objeção e sugestões de tratamento
   - Prioridade alta

4. **Alerta de Satisfação**
   - Disparada quando cliente demonstra satisfação/insatisfação
   - Inclui recomendações de ação
   - Enviada para vendedor responsável

5. **Dúvidas Pendentes**
   - Disparada quando cliente tem dúvidas não respondidas
   - Prioridade alta para resposta rápida

6. **Resumo Diário**
   - Enviado automaticamente todos os dias
   - Inclui estatísticas do dia anterior
   - Enviado para todos os vendedores

### Configuração de Email

Para habilitar notificações por email, configure as variáveis de ambiente:

```bash
export SMTP_SERVER="smtp.gmail.com"
export SMTP_PORT="587"
export EMAIL_USER="seu_email@gmail.com"
export EMAIL_PASSWORD="sua_senha_app"
```

**Nota**: Para Gmail, use uma "Senha de App" em vez da senha normal.

### Configuração do Slack

Para integração com Slack:

1. **Crie um Webhook** no seu workspace Slack
2. **Configure a variável** de ambiente:
   ```bash
   export SLACK_WEBHOOK_URL="https://hooks.slack.com/services/..."
   ```

### Personalização de Vendedores

Edite o arquivo `src/services/notification_service.py` para configurar vendedores:

```python
self.sellers_config = {
    'vendedor1@empresa.com': ['Vendedor 1'],
    'vendedor2@empresa.com': ['Vendedor 2'],
    'gerente@empresa.com': ['*']  # Recebe todas as notificações
}
```

## Exportação de Dados

### Planilhas Excel

O sistema gera planilhas Excel com:

- **Aba "Leads"**: Dados completos de todos os leads
- **Aba "Estatísticas"**: Resumo e métricas
- **Formatação Condicional**: Cores baseadas no status
- **Auto-ajuste**: Largura das colunas otimizada

### Arquivos CSV

Formato simples para importação em outras ferramentas:
- Codificação UTF-8 com BOM
- Separador por vírgula
- Compatível com Excel e Google Sheets

### Campos Exportados

| Campo | Descrição |
|-------|-----------|
| ID | Identificador único do lead |
| Telefone | Número de telefone do cliente |
| Nome | Nome do cliente (se informado) |
| Status | Status atual do lead |
| Tipo de Objeção | Categoria da objeção (se houver) |
| Detalhes da Objeção | Descrição detalhada da objeção |
| Última Mensagem | Última mensagem recebida |
| Cliente Satisfeito | Nível de satisfação (Sim/Não/Não informado) |
| Dúvidas Pendentes | Se há dúvidas não respondidas |
| Vendedor Responsável | Vendedor atribuído ao lead |
| Data de Criação | Quando o lead foi criado |
| Última Atualização | Última modificação dos dados |

## Troubleshooting

### Problemas Comuns

#### 1. Erro "ModuleNotFoundError"
**Problema**: Dependências não instaladas
**Solução**:
```bash
source venv/bin/activate
pip install -r requirements.txt
```

#### 2. Erro de Conexão com Banco
**Problema**: Banco de dados não criado
**Solução**: O banco é criado automaticamente na primeira execução. Verifique permissões da pasta `src/database/`.

#### 3. IA Não Funciona
**Problema**: API key do OpenAI não configurada
**Solução**:
```bash
export OPENAI_API_KEY="sua_api_key_aqui"
```

#### 4. Notificações Não Enviadas
**Problema**: Configurações de email incorretas
**Solução**: Verifique as variáveis de ambiente SMTP e use senha de app para Gmail.

#### 5. Webhook Não Recebe Mensagens
**Problema**: URL não acessível ou configuração incorreta
**Solução**:
- Verifique se a aplicação está rodando em `0.0.0.0:5000`
- Configure HTTPS em produção
- Teste com ferramentas como ngrok para desenvolvimento

### Logs e Debugging

Para habilitar logs detalhados:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Performance

Para melhor performance em produção:

1. **Use PostgreSQL** em vez de SQLite
2. **Configure Redis** para cache
3. **Use Gunicorn** como servidor WSGI
4. **Implemente rate limiting** para APIs

## Contribuição

### Estrutura de Desenvolvimento

1. **Fork** o projeto
2. **Crie uma branch** para sua feature (`git checkout -b feature/nova-funcionalidade`)
3. **Commit** suas mudanças (`git commit -am 'Adiciona nova funcionalidade'`)
4. **Push** para a branch (`git push origin feature/nova-funcionalidade`)
5. **Abra um Pull Request**

### Padrões de Código

- Use **PEP 8** para Python
- **Docstrings** para todas as funções
- **Type hints** quando possível
- **Testes unitários** para novas funcionalidades

### Roadmap

Funcionalidades planejadas para próximas versões:

- [ ] Integração com CRM (Pipedrive, HubSpot)
- [ ] Chatbot automático para respostas iniciais
- [ ] Análise de sentimento mais avançada
- [ ] Dashboard com gráficos interativos
- [ ] API para integrações externas
- [ ] Suporte a múltiplos idiomas
- [ ] Mobile app para vendedores

---

**Desenvolvido por Manus AI**  
Para suporte técnico, entre em contato através do dashboard ou abra uma issue no repositório.

